# Product Detail Page Design With Image Slider HTML CSS & Javascript

A Pen created on CodePen.io. Original URL: [https://codepen.io/fadzrinmadu/pen/JjWmxaj](https://codepen.io/fadzrinmadu/pen/JjWmxaj).

Product detail page design with image slider html css and javascript reference from youtube GeekProbin